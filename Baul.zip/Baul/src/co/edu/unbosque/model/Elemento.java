package co.edu.unbosque.model;

public class Elemento {
	private String nombre;
	private double valor;
	private double peso;
	private int cantidad;
	private boolean fraccionar;
	private double valorpeso;

	public Elemento(String n, double v, double p, int c, boolean f) {
		nombre=n;
		valor =v;
		peso  =p;
		cantidad =c;
		fraccionar =f;
		setValorpeso(valor / peso);
	}

	public boolean isFraccionar() {
		return fraccionar;
	}

	public void setFraccionar(boolean fraccionar) {
		this.fraccionar = fraccionar;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public String toString() {
		return String.format("%-15s %,12.2f %,12.2f", nombre, valor, peso);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getValorpeso() {
		return valorpeso;
	}

	public void setValorpeso(double valorpeso) {
		this.valorpeso = valorpeso;
	}
	
	
}
