package co.edu.unbosque.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Baul {

	List<Elemento> almacen = new ArrayList();
	List<Elemento> tmpBaul = new ArrayList();
	ArrayList<Elemento> baul = new ArrayList();

	double pesoMaximo;
	double[]beneficioElemento;

	public Baul(double p) {
		pesoMaximo = p;
		cargarDatos();
	}
	
	public void cargarDatos() {
		almacen.add(new Elemento("TV", 300, 15,0,false));
		almacen.add(new Elemento("PS3", 100, 3, 0,false));
		almacen.add(new Elemento("Libro Java", 10, 1,0,false));
		almacen.add(new Elemento("DVD Player", 5, 0.5,0,false));
		almacen.add(new Elemento("Blu-Ray", 50, 0.5,0,false));
		almacen.add(new Elemento("Balon", 30, 0.5,0,false));
		almacen.add(new Elemento("iPod", 150, 1,0,false));
		almacen.add(new Elemento("Printer", 20, 4,0,false));
		almacen.add(new Elemento("VideoBeam", 200, 4,0,false));
		almacen.add(new Elemento("LapTop", 20, 3,0,false));
		almacen.add(new Elemento("iPad", 150, 2,0,false));
		almacen.add(new Elemento("PC", 100, 5,0,false));
		almacen.add(new Elemento("BlackBerry", 150, 0.5,0,false));
	}

	public void inicializar1(String nombre, double valor, double peso,int cantidad, boolean fraccion) {
		almacen.add(new Elemento(nombre, valor, peso,0,false));
	}
	
	public void inicializar3(String nombre, double valor, double peso, int cantidad, boolean fraccionar) {
		almacen.add(new Elemento(nombre, valor, peso, cantidad, fraccionar));
	}
	
	public void ordenarArray() {
		baul.clear();
		beneficioElemento = new double [almacen.size()];
		for (int i = 0; i < almacen.size(); i++) {
			beneficioElemento[i]=almacen.get(i).getValorpeso();
		}
		Arrays.sort(beneficioElemento);	
	}
	
	public String solucionVariante1() {
		ordenarArray();
		double a = pesoMaximo;
		for (int i = beneficioElemento.length-1; i >=0; i--) {
			for (int j = 0; j < almacen.size(); j++) {
				if (beneficioElemento[i]==almacen.get(j).getValorpeso()) {
					tmpBaul.add(almacen.get(j));
					almacen.remove(j);
				}
			}
		}
		for (int i = 0; i <tmpBaul.size(); i++) {
			if ((a-tmpBaul.get(i).getPeso())>=0) {
				baul.add(tmpBaul.get(i));
				a-=tmpBaul.get(i).getPeso();
			}
			if (a==0) {
				break;
			}
		}
		return mostrarBaul();
	}
	
	public void solucionVariante2y3() {
		double cambio = pesoMaximo;
		double total =0.0;
		for(int i= tmpBaul.size()-1; i>= 0; i--) {
			int cantidad=0;
			while(total<=cambio && tmpBaul.get(i).getCantidad()>0) {
				total += tmpBaul.get(i).getPeso();
				tmpBaul.get(i).setCantidad(tmpBaul.get(i).getCantidad()-1);
				cantidad++;	
			}
			tmpBaul.get(i).setCantidad(cantidad);
			baul.add(tmpBaul.get(i));	
		}
		tmpBaul.clear();
	}
	
	
	double getPeso(List<Elemento> tmp) {
		double respuesta = 0;
		for (Elemento e : tmp)
			respuesta += e.getPeso();
		return respuesta;
	}

	double getValor(List<Elemento> tmp) {
		double respuesta = 0;
		for (Elemento e : tmp)
			respuesta += e.getValor();
		return respuesta;
	}
	
	public String verSolucion() {
		String r = "\nArreglo Solución\n";
		for (int i = 0; i < almacen.size(); i++) {
				r = r + " Nombre: " + almacen.get(i).getNombre() + ", Peso: " + almacen.get(i).getPeso() + ", Valor: "+ almacen.get(i).getValor()+"\n";
		}
		return r;
	}
	
	public String mostrarBaul() {
		double pesoBaul=0;
		double valorBaul=0;
		String rt= "";
		for(Elemento c : baul) {
			rt+= "" + c +"\n";
			pesoBaul+= c.getPeso();
			valorBaul+= c.getValorpeso();
		}
		rt = rt +"--------------";
		rt = rt +"Peso= " +pesoBaul;
		rt = rt +"Valor= " +valorBaul; 
		return rt;
	}
	
	public String mostrarAlmacen() {
		double pesoBaul=0;
		double valorBaul=0;
		String rt= "";
		for(Elemento c : almacen) {
			rt+= "" + c +"\n";
			pesoBaul+= c.getPeso();
			valorBaul+= c.getValorpeso();
		}
		rt = rt +"--------------";
		rt = rt +"Peso= " +pesoBaul;
		rt = rt +"Valor= " +valorBaul; 
		return rt;
	}
	
	
}
