package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import co.edu.unbosque.model.Baul;
import co.edu.unbosque.view.Ventana;

public class Controller  implements ActionListener{

	private Ventana ventana;
	private Baul baul;

	/**
	 * Este método inicializa los componentes que se van a utilizar, así mismo las condiciones de la ventana
	 */
	public Controller() {

		ventana = new Ventana();
		ventana.setVisible(true);
		ventana.setResizable(false);
		asignarOyentes();

	}

	public void asignarOyentes() {
		//botones panel de bienvenida
		ventana.getPbienvenida().getVar1().addActionListener(this);
		ventana.getPbienvenida().getVar3().addActionListener(this);
		ventana.getPv1().getVolver().addActionListener(this);
		ventana.getPv1().getGuardar().addActionListener(this);
		ventana.getPv1().getMostrar().addActionListener(this);
		ventana.getPv3().getVolver().addActionListener(this);
		ventana.getPv3().getGuardar().addActionListener(this);
		ventana.getPv3().getMostrar().addActionListener(this);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String comando = e.getActionCommand();
		
		if(comando.equals("USARVAR1")) {
			try {
			ventana.getPbienvenida().getP().getText();
			double p = Double.parseDouble(ventana.getPbienvenida().getP().getText());
			baul = new Baul(p);
			ventana.getContentPane().remove(ventana.getPbienvenida());
			ventana.getContentPane().add(ventana.getPv1());
			ventana.getPv1().setVisible(true);
			}catch(NumberFormatException a) {
				ventana.mostrarInformacionError("Ingrese un número válido");
			}
		}

		else if(comando.equals("USARVAR3")) {
			try {
			ventana.getPbienvenida().getP().getText();
			double p = Double.parseDouble(ventana.getPbienvenida().getP().getText());
			baul = new Baul(p);
			ventana.getContentPane().remove(ventana.getPbienvenida());
			ventana.getContentPane().add(ventana.getPv3());
			ventana.getPv3().setVisible(true);	
			}catch(NumberFormatException b) {
				ventana.mostrarInformacionError("Ingrese un número válido");
			}
		}
		else if(comando.equals("Menuvar1")) {
			ventana.getContentPane().remove(ventana.getPv1());
			ventana.getContentPane().add(ventana.getPbienvenida());
			ventana.getPbienvenida().setVisible(true);
		}
		else if(comando.equals("Menuvar3")) {
			ventana.getContentPane().remove(ventana.getPv3());
			ventana.getContentPane().add(ventana.getPbienvenida());
			ventana.getPbienvenida().setVisible(true);
		}
		else if(comando.equals("mostrar1")){
			ventana.getPv1().getRes().setText(baul.mostrarBaul());
		}
		else if(comando.equals("mostrar2")){
			ventana.getPv3().getRes().setText(baul.mostrarAlmacen());
		}
		else if(comando.equals("Gdatos1")) {
			try{
				String nombre = ventana.getPv1().getN().getText();
				double valor =Double.parseDouble(ventana.getPv1().getV().getText());
				double peso =Double.parseDouble(ventana.getPv1().getP().getText());
				double cantidad =0;
				boolean fraccion=false;
				baul.inicializar1(nombre, valor, peso, 0, false);
				ventana.getPv1().getRes().setText(baul.solucionVariante1());
			}
			catch(NumberFormatException e1) {
				ventana.mostrarInformacionError("Ingrese valores válidos");
			}
		}
		else if(comando.equals("Gdatos2")) {
			try {
				String nombre = ventana.getPv3().getN().getText();
				double valor = Double.parseDouble(ventana.getPv3().getV().getText());
				double peso = Double.parseDouble(ventana.getPv3().getP().getText());
				int cantidad = Integer.parseInt((String) ventana.getPv3().getC().getText());
				double valorFraccion=Double.parseDouble(ventana.getPv3().getF().getText());
				boolean fraccionable = ventana.getPv3().getCheck().isSelected();
				baul.inicializar3(nombre, valor, peso, cantidad, fraccionable);
				
				if(!fraccionable) {
					valorFraccion = 0;
					if(cantidad>1) {
						for(int i=1; i<cantidad; i++) {
							baul.inicializar3(nombre, valor, peso, cantidad, false);
						}
					}	
				}
				if(fraccionable) {
					
					if (valorFraccion >= 2) {
						for(int i= 0; i<cantidad * valorFraccion; i++) {
							double b = peso/valorFraccion;
							baul.inicializar3("Pedazo de: " +nombre, valor/valorFraccion, b, (int) valorFraccion, true);
						}
					}
					else {
						valorFraccion = 0;
						if(cantidad>1) {
							for(int i=1; i<cantidad; i++) {
								baul.inicializar3(nombre, valor, peso, cantidad, false);
							}
						}
					}
					
				}
				ventana.getPv3().getRes().setText(baul.verSolucion());
			}
			catch(Exception e1) {
				ventana.mostrarInformacionError("Ingrese valores válidos");
			}
		}
		
		ventana.repaint();

	}

}
