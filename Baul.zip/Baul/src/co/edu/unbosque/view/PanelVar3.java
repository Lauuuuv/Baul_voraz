package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class PanelVar3 extends JPanel {

	private JLabel ingresar;
	private JLabel nombre;
	private JLabel valor;
	private JLabel peso;
	private JLabel cantidad;
	private JLabel fraccionar;
	private JTextField n;
	private JTextField v;
	private JTextField p;
	private JTextField c;
	private JTextField f;

	private JTextPane res;
	private JButton volver;
	private JButton guardar;
	private JButton mostrar;
	private JScrollPane scroll;

	private JCheckBox check;
	
	public PanelVar3() {
		setLayout(null);
		inicializarComponentes();
		setVisible(false);
	}
	
	public void inicializarComponentes() {
		setBackground(Color.PINK);

		Border border = new LineBorder(Color.BLACK, 3, true);
		TitledBorder tb = new TitledBorder(border, "Variación 3");
		Font fuente = new Font("Tahoma", Font.ITALIC, 15);
		tb.setTitleFont(fuente);
		tb.setTitleColor(Color.BLACK);
		setBorder(tb);
		
		ingresar  = new JLabel("Esta variante te permite agregar cantidad y fraccionar elementos, también visualizar la lista actual.");
		add(ingresar);
		ingresar.setBounds(110,20, 600, 50);
		
		nombre = new JLabel("Nombre:");
		add(nombre);
		nombre.setBounds(10,60, 80, 50);
		n = new JTextField();
		add(n);
		n.setBounds(80,72, 220, 25);
		
		valor = new JLabel("Valor:");
		add(valor);
		valor.setBounds(10,88, 80, 50);
		v = new JTextField();
		add(v);
		v.setBounds(80,100, 220, 25);
		
		peso = new JLabel ("Peso:");
		add(peso);
		peso.setBounds(10,115, 80, 50);
		p = new JTextField();
		add(p);
		p.setBounds(80,128, 220, 25);
		
		cantidad = new JLabel ("Cantidad:");
		add(cantidad);
		cantidad.setBounds(10,140, 80, 50);
		
		c = new JTextField();
		add(c);
		c.setBounds(80,155, 220, 25);

		fraccionar = new JLabel ("Fraccionar:");
		add(fraccionar);
		fraccionar.setBounds(10,165, 80, 50);
		f = new JTextField();
		f.setBounds(80,183, 220, 25);
		add(f);
		
		check = new JCheckBox();
		add(check);
		check.setBounds(10,200, 50, 25);
		check.setBackground(Color.pink);
		
		volver = new JButton("Menú");
		add(volver);
		volver.setBounds(10, 330, 100, 20);
		volver.setActionCommand("Menuvar3");
		
		guardar = new JButton("Guardar datos");
		add(guardar);
		guardar.setBounds(120, 330, 170, 20);
		guardar.setActionCommand("Gdatos2");
		
		mostrar = new JButton("Mostrar lista");
		add(mostrar);
		mostrar.setBounds(420, 330, 170, 20);
		mostrar.setActionCommand("mostrar2");
		
		res = new JTextPane();
		res.setEditable(false);
		JScrollPane scroll = new JScrollPane(res);
		scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
		scroll.setBounds(350, 72, 310, 250);
		add(scroll);
		
	}
	
	public JLabel getIngresar() {
		return ingresar;
	}
	
	public JButton getMostrar() {
		return mostrar;
	}

	public void setMostrar(JButton mostrar) {
		this.mostrar = mostrar;
	}

	public JTextField getC() {
		return c;
	}

	public void setC(JTextField c) {
		this.c = c;
	}

	public JTextField getF() {
		return f;
	}

	public void setF(JTextField f) {
		this.f = f;
	}

	public JCheckBox getCheck() {
		return check;
	}

	public void setCheck(JCheckBox check) {
		this.check = check;
	}

	public void setIngresar(JLabel ingresar) {
		this.ingresar = ingresar;
	}

	public JLabel getNombre() {
		return nombre;
	}

	public void setNombre(JLabel nombre) {
		this.nombre = nombre;
	}

	public JLabel getValor() {
		return valor;
	}

	public void setValor(JLabel valor) {
		this.valor = valor;
	}

	public JLabel getPeso() {
		return peso;
	}

	public void setPeso(JLabel peso) {
		this.peso = peso;
	}

	public JLabel getCantidad() {
		return cantidad;
	}

	public void setCantidad(JLabel cantidad) {
		this.cantidad = cantidad;
	}

	public JLabel getFraccionar() {
		return fraccionar;
	}

	public void setFraccionar(JLabel fraccionar) {
		this.fraccionar = fraccionar;
	}

	public JTextField getN() {
		return n;
	}

	public void setN(JTextField n) {
		this.n = n;
	}

	public JTextField getV() {
		return v;
	}

	public void setV(JTextField v) {
		this.v = v;
	}

	public JTextField getP() {
		return p;
	}

	public void setP(JTextField p) {
		this.p = p;
	}

	
	public JTextPane getRes() {
		return res;
	}

	public void setRes(JTextPane res) {
		this.res = res;
	}

	public JButton getVolver() {
		return volver;
	}

	public void setVolver(JButton volver) {
		this.volver = volver;
	}

	public JButton getGuardar() {
		return guardar;
	}

	public void setGuardar(JButton guardar) {
		this.guardar = guardar;
	}

	public JScrollPane getScroll() {
		return scroll;
	}

	public void setScroll(JScrollPane scroll) {
		this.scroll = scroll;
	}
	
	
}

