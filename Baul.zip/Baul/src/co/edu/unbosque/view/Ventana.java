package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Ventana extends JFrame {

	private PanelBienvenida pbienvenida;
	private PanelVar1 pv1;
	private PanelVar3 pv3;

	public Ventana () {

		setTitle("LECTOR DE ARCHIVOS");
		setSize(700, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		getContentPane().setLayout(null);

		inicializarComponentes();

		setResizable(true);
		setLocationRelativeTo(null);
		setVisible(false);

	}

	public void inicializarComponentes() {

		pbienvenida= new PanelBienvenida();
		pbienvenida.setSize(684, 360);
		getContentPane().add(pbienvenida);

		pv1 = new PanelVar1();
		pv1.setSize(684,360);

		pv3 = new PanelVar3();
		pv3.setSize(684,360);	

	}


	public void mostrarMensaje(String mensaje ) {
		JOptionPane.showMessageDialog(null, mensaje);
	}

	public void mostrarInformacionError(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje, "Error" , JOptionPane.ERROR_MESSAGE);

	}

	public PanelBienvenida getPbienvenida() {
		return pbienvenida;
	}

	public void setPbienvenida(PanelBienvenida pbienvenida) {
		this.pbienvenida = pbienvenida;
	}

	public PanelVar1 getPv1() {
		return pv1;
	}

	public void setPv1(PanelVar1 pv1) {
		this.pv1 = pv1;
	}

	public PanelVar3 getPv3() {
		return pv3;
	}

	public void setPv3(PanelVar3 pv3) {
		this.pv3 = pv3;
	}

}
