package co.edu.unbosque.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/*
 * Clase de tipo JPanel
 */
public class PanelBienvenida extends JPanel{

	private JLabel inicio;
	private JLabel mensaje;
	private JLabel peso;
	private JTextField p;
	private JButton g;
	private JButton var1;
	private JButton var3;


	/*
	 * Método constructor
	 */
	public PanelBienvenida() {

		setLayout(null);
		inicializarComponentes();
		setVisible(true);
	}

	/*
	 * Método para crear y ubicar los elementos de la interfaz gráfica
	 */
	public void inicializarComponentes() {

		setBackground(Color.PINK);

		Border border = new LineBorder(Color.BLACK, 3, true);
		TitledBorder tb = new TitledBorder(border, "Inicio");
		Font fuente = new Font("Tahoma", Font.ITALIC, 15);
		tb.setTitleFont(fuente);
		tb.setTitleColor(Color.BLACK);
		setBorder(tb);

		peso = new JLabel("Ingrese el peso máximo de su baúl");
		add(peso);
		peso.setBounds(250, 50, 250, 100);
		
		p = new JTextField();
		add(p);
		p.setBounds(280, 118, 150, 30);
		
		inicio = new JLabel("BIENVENID@, este es un programa que te permite gestionar el almacenamiento de tu baúl" + "\n" );
		add(inicio);
		inicio.setBounds(90, 10, 550, 100);
		
		mensaje = new JLabel("Por favor selecciona la variante que deseas utilizar." );
		add(mensaje);
		mensaje.setBounds(200, 110, 800, 150);
		
		var1 = new JButton("VARIANTE 1");
		add(var1);
		var1.setActionCommand("USARVAR1");
		var1.setBounds(40, 220, 260, 90);
		
		var3 = new JButton("VARIANTE 2 y 3");
		add(var3);
		var3.setActionCommand("USARVAR3");
		var3.setBounds(390, 220, 260, 90);
	}

	/*
	 * Setters y getters
	 */
	
	public JLabel getMensaje() {
		return mensaje;
	}

	public JLabel getPeso() {
		return peso;
	}

	public void setPeso(JLabel peso) {
		this.peso = peso;
	}

	public JTextField getP() {
		return p;
	}

	public void setP(JTextField p) {
		this.p = p;
	}

	public JButton getG() {
		return g;
	}

	public void setG(JButton g) {
		this.g = g;
	}

	public void setMensaje(JLabel mensaje) {
		this.mensaje = mensaje;
	}

	public JLabel getInicio() {
		return inicio;
	}

	public void setInicio(JLabel inicio) {
		this.inicio = inicio;
	}

	public JButton getVar1() {
		return var1;
	}

	public void setVar1(JButton var1) {
		this.var1 = var1;
	}

	public JButton getVar3() {
		return var3;
	}

	public void setVar3(JButton var3) {
		this.var3 = var3;
	}	

}
